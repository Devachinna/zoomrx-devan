import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  row = 5;
  column = 5;
  title = 'component-overview';
  values: any = [];
  obstacles: any = [1, 2, 3, 4, 5];
  obstacleFound = new Subject<any>();
  ngOnInit() {
    this.obstacleFound.subscribe((data: any) => {
      this.checkLeftForHole(data.split('')[0], data.split('')[1]);
      this.checkRightForHole(data.split('')[0], data.split('')[1]);
    });
  }
  create2dArray(k: number, l: number) {
    let things = [];
    for (var i = 0; i < k; i++) {
      let things2d = [];
      for (var j = 0; j < l; j++) {
        things2d.push([i, j]);
      }
      things.push(things2d);
    }
    this.values = things;
  }
  drag(ev: any) {
    ev.dataTransfer.setData('text', ev.target.id);
  }

  drop(ev: any) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData('text');
    ev.target.appendChild(document.getElementById(data));
    // const obstraclesIdentifier = this.checkForObstacles();
    // obstraclesIdentifier.then(response => {
    //   console.log('Obstacles', response);
    // });
  }
  allowDrop(ev: any) {
    ev.preventDefault();
  }
  pourWater(id: string) {
    const splitString = id.split('');
    const currentSelectedcolumn = splitString[splitString.length - 1];
    const currentSelectedrow = splitString[splitString.length - 2];
    this.checkForLoop(currentSelectedcolumn);
  }
  // async checkForObstacles(){
  //   let obstaclesArray = [];
  //   for (let rowAbstacles = 0; rowAbstacles < this.row; rowAbstacles++) {
  //     for (let columnAbstacles = 0; columnAbstacles < this.column; columnAbstacles++) {
  //       const localElement = document.getElementById(`inner${rowAbstacles}${columnAbstacles}`) as HTMLElement;
  //       if(localElement.hasChildNodes()) {
  //         console.log('Obstacles are in : ' + `${rowAbstacles}${columnAbstacles}`);
  //         obstaclesArray.push(`${rowAbstacles}${columnAbstacles}`);
  //       }
  //     }
  //   }
  //   return await obstaclesArray;
  // }
  checkForLoop(column: any, rows: any = 1) {
    let columnNo = column;
    loop1: for (var row = rows; row < this.row; row++) {
      const myElement = document.getElementById(
        `inner${row}${columnNo}`
      ) as HTMLElement;
      if (myElement.hasChildNodes() && row == 1) {
        break loop1;
      } else if (myElement.hasChildNodes() && row > 1) {
        this.obstacleFound.next(`${row}${columnNo}`);
        break;
      } else {
        (document.querySelector(
          `#inner${row}${columnNo}`
        ) as HTMLElement).style.background = '#ff55ff';
        if (row == this.row) {
        }
      }
    }
  }
  checkLeftForHole(row, column) {
    const columnLocal = column - 1;
    const rowLocal = row - 1;
    if (columnLocal >= 0 && rowLocal >= 1) {
      const localElement = document.getElementById(
        `inner${rowLocal}${columnLocal}`
      ) as HTMLElement;
      if (localElement.hasChildNodes()) {
        const upperElement = document.getElementById(
          `inner${rowLocal - 1}${columnLocal}`
        ) as HTMLElement;
        // this.checkLeftForHole(rowLocal, columnLocal);
        if (upperElement.hasChildNodes() && rowLocal - 1 > 1) {
          // this.checkLeftForHole(rowLocal, columnLocal);
          this.obstacleFound.next(`${rowLocal}${columnLocal}`);
        } else {
          (document.querySelector(
            `#inner${rowLocal - 1}${columnLocal}`
          ) as HTMLElement).style.background = '#ff55ff';
          this.checkForLoop(columnLocal, rowLocal);
        }
      } else {
        (document.querySelector(
          `#inner${rowLocal}${columnLocal}`
        ) as HTMLElement).style.background = '#ff55ff';
        this.checkForLoop(columnLocal, rowLocal);
      }
    }
  }
  checkRightForHole(row, column) {
    const columnLocal = 1 + Number(column);
    const rowLocal = row - 1;
    if (columnLocal <= this.column && rowLocal <= this.row) {
      const localElement = document.getElementById(
        `inner${rowLocal}${columnLocal}`
      ) as HTMLElement;
      if (localElement.hasChildNodes()) {
        const upperElement = document.getElementById(
          `inner${rowLocal - 1}${columnLocal}`
        ) as HTMLElement;
        // this.checkLeftForHole(rowLocal, columnLocal);
        if (upperElement.hasChildNodes() && rowLocal - 1 > 1) {
          // this.checkLeftForHole(rowLocal, columnLocal);
          this.obstacleFound.next(`${rowLocal}${columnLocal}`);
        } else {
          (document.querySelector(
            `#inner${rowLocal - 1}${columnLocal}`
          ) as HTMLElement).style.background = '#ff55ff';
          this.checkForLoop(columnLocal, rowLocal);
        }
      } else {
        (document.querySelector(
          `#inner${rowLocal}${columnLocal}`
        ) as HTMLElement).style.background = '#ff55ff';
        this.checkForLoop(columnLocal, rowLocal);
      }
    }
  }
}

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
